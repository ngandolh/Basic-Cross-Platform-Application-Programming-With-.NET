﻿namespace SaleManagementWinApp
{
    partial class frmProductDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            lb3 = new System.Windows.Forms.Label();
            lb2 = new System.Windows.Forms.Label();
            lb1 = new System.Windows.Forms.Label();
            txtFLowerBouquetID = new System.Windows.Forms.TextBox();
            txtCategoryID = new System.Windows.Forms.TextBox();
            txtFLowerBouquetName = new System.Windows.Forms.TextBox();
            txtDescription = new System.Windows.Forms.TextBox();
            txtSupplierID = new System.Windows.Forms.TextBox();
            txtFlowerBouquetStatus = new System.Windows.Forms.TextBox();
            txtUnitsInStock = new System.Windows.Forms.TextBox();
            txtUnitPrice = new System.Windows.Forms.TextBox();
            btnSave = new System.Windows.Forms.Button();
            btnClose = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(63, 76);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(135, 20);
            label1.TabIndex = 0;
            label1.Text = "FLower Bouquet ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(63, 236);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(88, 20);
            label2.TabIndex = 1;
            label2.Text = "Category ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(63, 416);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(160, 20);
            label3.TabIndex = 2;
            label3.Text = "FLower Bouquet Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(63, 579);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(85, 20);
            label4.TabIndex = 3;
            label4.Text = "Description";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(653, 579);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(83, 20);
            label5.TabIndex = 7;
            label5.Text = "Supplier ID";
            // 
            // lb3
            // 
            lb3.AutoSize = true;
            lb3.Location = new System.Drawing.Point(653, 419);
            lb3.Name = "lb3";
            lb3.Size = new System.Drawing.Size(160, 20);
            lb3.TabIndex = 6;
            lb3.Text = "FLower Bouquet Status";
            // 
            // lb2
            // 
            lb2.AutoSize = true;
            lb2.Location = new System.Drawing.Point(653, 236);
            lb2.Name = "lb2";
            lb2.Size = new System.Drawing.Size(98, 20);
            lb2.TabIndex = 5;
            lb2.Text = "Units In Stock";
            // 
            // lb1
            // 
            lb1.AutoSize = true;
            lb1.Location = new System.Drawing.Point(653, 76);
            lb1.Name = "lb1";
            lb1.Size = new System.Drawing.Size(72, 20);
            lb1.TabIndex = 4;
            lb1.Text = "Unit Price";
            // 
            // txtFLowerBouquetID
            // 
            txtFLowerBouquetID.Location = new System.Drawing.Point(229, 76);
            txtFLowerBouquetID.Name = "txtFLowerBouquetID";
            txtFLowerBouquetID.Size = new System.Drawing.Size(367, 27);
            txtFLowerBouquetID.TabIndex = 8;
            // 
            // txtCategoryID
            // 
            txtCategoryID.Location = new System.Drawing.Point(229, 236);
            txtCategoryID.Name = "txtCategoryID";
            txtCategoryID.Size = new System.Drawing.Size(367, 27);
            txtCategoryID.TabIndex = 9;
            // 
            // txtFLowerBouquetName
            // 
            txtFLowerBouquetName.Location = new System.Drawing.Point(229, 416);
            txtFLowerBouquetName.Name = "txtFLowerBouquetName";
            txtFLowerBouquetName.Size = new System.Drawing.Size(367, 27);
            txtFLowerBouquetName.TabIndex = 10;
            // 
            // txtDescription
            // 
            txtDescription.Location = new System.Drawing.Point(229, 576);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new System.Drawing.Size(367, 27);
            txtDescription.TabIndex = 11;
            // 
            // txtSupplierID
            // 
            txtSupplierID.Location = new System.Drawing.Point(819, 576);
            txtSupplierID.Name = "txtSupplierID";
            txtSupplierID.Size = new System.Drawing.Size(367, 27);
            txtSupplierID.TabIndex = 15;
            // 
            // txtFlowerBouquetStatus
            // 
            txtFlowerBouquetStatus.Location = new System.Drawing.Point(819, 416);
            txtFlowerBouquetStatus.Name = "txtFlowerBouquetStatus";
            txtFlowerBouquetStatus.Size = new System.Drawing.Size(367, 27);
            txtFlowerBouquetStatus.TabIndex = 14;
            // 
            // txtUnitsInStock
            // 
            txtUnitsInStock.Location = new System.Drawing.Point(819, 236);
            txtUnitsInStock.Name = "txtUnitsInStock";
            txtUnitsInStock.Size = new System.Drawing.Size(367, 27);
            txtUnitsInStock.TabIndex = 13;
            // 
            // txtUnitPrice
            // 
            txtUnitPrice.Location = new System.Drawing.Point(819, 76);
            txtUnitPrice.Name = "txtUnitPrice";
            txtUnitPrice.Size = new System.Drawing.Size(367, 27);
            txtUnitPrice.TabIndex = 12;
            // 
            // btnSave
            // 
            btnSave.Location = new System.Drawing.Point(304, 662);
            btnSave.Name = "btnSave";
            btnSave.Size = new System.Drawing.Size(94, 29);
            btnSave.TabIndex = 16;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnClose
            // 
            btnClose.Location = new System.Drawing.Point(851, 662);
            btnClose.Name = "btnClose";
            btnClose.Size = new System.Drawing.Size(94, 29);
            btnClose.TabIndex = 17;
            btnClose.Text = "Close";
            btnClose.UseVisualStyleBackColor = true;
            btnClose.Click += btnClose_Click;
            // 
            // frmProductDetail
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1230, 720);
            Controls.Add(btnClose);
            Controls.Add(btnSave);
            Controls.Add(txtSupplierID);
            Controls.Add(txtFlowerBouquetStatus);
            Controls.Add(txtUnitsInStock);
            Controls.Add(txtUnitPrice);
            Controls.Add(txtDescription);
            Controls.Add(txtFLowerBouquetName);
            Controls.Add(txtCategoryID);
            Controls.Add(txtFLowerBouquetID);
            Controls.Add(label5);
            Controls.Add(lb3);
            Controls.Add(lb2);
            Controls.Add(lb1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmProductDetail";
            Text = "frmProductDetail";
            Load += frmProductDetail_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb3;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.TextBox txtFLowerBouquetID;
        private System.Windows.Forms.TextBox txtCategoryID;
        private System.Windows.Forms.TextBox txtFLowerBouquetName;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.TextBox txtSupplierID;
        private System.Windows.Forms.TextBox txtFlowerBouquetStatus;
        private System.Windows.Forms.TextBox txtUnitsInStock;
        private System.Windows.Forms.TextBox txtUnitPrice;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
    }
}