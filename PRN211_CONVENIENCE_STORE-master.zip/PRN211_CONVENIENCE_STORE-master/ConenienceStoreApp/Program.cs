﻿using System;

namespace ConenienceStoreApp
{
    public class Class1
    {
    }
}
